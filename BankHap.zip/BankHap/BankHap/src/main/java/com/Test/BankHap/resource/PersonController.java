package com.Test.BankHap.resource;

import com.Test.BankHap.model.Person;
import com.Test.BankHap.repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class PersonController {

    @Autowired
    private PersonRepository repository;

    @PostMapping("/addPerson")
    public String savePerson(@RequestBody Person person){

        repository.save(person);
        return "Added Person with ID: " + person.getId();
    }
    @GetMapping("/findAllPersons")
    public List<Person> getPersons(){
        return repository.findAll();
    }
    @GetMapping("/findAllPersons/{id}")
    public Optional<Person> getPerson(@PathVariable int id){
        return repository.findById(id);
    }
    @DeleteMapping("/delete/{id}")
    public String deletePerson(@PathVariable int id){
         repository.deleteById(id);
         return "Person " + id + " is deleted";
    }
    @PutMapping(value = "/update{id}")
    public String updatePerson(@ModelAttribute Person person) {
         repository.save(person);
        return "Updated Person with ID: " + person.getId();
    }
}
