package com.Test.BankHap.model;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Getter
@Setter
@ToString

@Document(collection = "Person")
public class Person {
    @Id
    private String id;
    private String name;
    private int age;
    private double height;
    private double weight;
    private Gender gender;
    private Address address;
}

class Address {

    private State state;
    private String city;
    private String street;
    private String zipcode;
    private boolean containsAnimals;
}
enum Gender {
    MALE,
    FEMALE,
    OTHER
}
enum State {
    ISRAEL,
    USA
}