package com.Test.BankHap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankHapApplicationTests {

	@Test
	void contextLoads() {
	}

}
